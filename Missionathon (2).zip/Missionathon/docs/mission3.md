
# Mission 72 — Mission 3 Documentation

## 1. Overview

Mission 3 focuses on visualizing security incidents and authentication activity in the Mission 72 dashboard.

The goal is to help security analysts understand suspicious login activity, investigate related alerts, identify high-risk users, and observe relationships between users and hosts.

The visualization module is implemented in:

- `src/mission72/visualizations.py`
- `src/mission72/static/app.js`
- `src/mission72/static/styles.css`

Tests are located in:

- `tests/test_mission3.py`

Dashboard integration is handled by the existing server implementation in `src/mission72/server.py`.

## 2. Objectives

The main objectives of Mission 3 are:

1. Display authentication events in chronological order.
2. Explain alerts using evidence and confidence information.
3. Display risk scores for individual users.
4. Show which detection rules contribute to user risk.
5. Visualize relationships between users and hosts.
6. Group related alerts into incidents.
7. Display incident severity, timestamps, affected accounts, and affected hosts.
8. Test visualization helper functions using synthetic authentication data.
9. Document risk scoring, evidence traceability, and implementation limitations.

## 3. Visualization Approach

### 3.1 Incident Timeline

The incident timeline displays authentication events in chronological order, helping analysts reconstruct the sequence of activity around a potential security incident.

Each event may contain:

- Timestamp
- Event type
- Username
- Hostname
- Event status
- Severity
- Description

The `build_timeline()` function in `visualizations.py` prepares and sorts events by timestamp.

Events with invalid timestamps should be excluded from the chronological timeline.

The dashboard JavaScript renders the timeline and supports filtering events by status or severity.

### 3.2 Alert Explanation and Evidence

Each alert can display information explaining why it was generated.

Recommended fields include:

- Detection rule name and identifier
- Confidence or evidence-strength label
- Supporting evidence
- Explanation
- Severity
- Related authentication events

Example:

| Field | Example |
|---|---|
| Detection rule | Repeated failed logins |
| Confidence | High |
| Evidence | Multiple failed authentication attempts |
| Explanation | Several login attempts failed |
| Severity | Medium |

The values in this table are illustrative examples, not actual security findings.

Evidence should be traceable to the underlying authentication logs or detection results. Analysts should be able to determine which events support each alert.

### 3.3 User Risk Breakdown

The user risk breakdown displays the risk score for each user and the contributions made by individual detection rules.

The `build_user_risk_breakdown()` function combines the points assigned to detection rules for each user.

The displayed risk score is capped at 100, while the raw total can be retained separately to preserve information about the combined rule contributions.

#### Illustrative severity thresholds

| Risk score | Severity |
|---|---|
| 0–29 | Low |
| 30–59 | Medium |
| 60–79 | High |
| 80–100 | Critical |

These thresholds are illustrative and must be aligned with the project's approved risk-scoring policy before being used as production rules.

The dashboard can display:

- Username
- Risk score
- Severity
- Detection rule contributions
- Rule points
- Confidence
- Explanation
- Supporting evidence

A high risk score indicates that an account may deserve closer investigation. It does not, by itself, prove that the account has been compromised.

### 3.4 User-to-Host Communication Graph

The user-to-host graph represents users and hosts as separate node types.

- User nodes represent accounts.
- Host nodes represent computers or servers.
- Edges represent recorded user-to-host relationships.
- Edge counts indicate how many matching events were observed.

The `build_user_host_graph()` function prepares the graph's nodes and edges.

The JavaScript renders the graph using SVG, without requiring an external visualization library.

The graph helps analysts identify which hosts an account accessed and where further investigation may be useful.

A recorded connection alone does not prove malicious activity. Its significance depends on the surrounding events and investigation context.

### 3.5 Incident Grouping

The `group_alerts_into_incidents()` function groups related alerts according to the implemented correlation rules.

For the basic implementation, alerts associated with the same user and occurring within a configured time window can be grouped into an incident.

The default window described by the starter implementation is 30 minutes.

An incident may contain:

- Incident identifier
- User account
- Start timestamp
- End timestamp
- Highest observed alert severity
- Affected accounts
- Affected hosts
- Related alerts

The basic grouping method does not necessarily correlate every available indicator, such as source IP addresses, detection-rule relationships, or attack-chain evidence.

The grouping behavior should be verified against the actual implementation and its unit tests.

## 4. Risk Scoring Method

The intended scoring approach uses additive detection-rule points.

For a user:

**Raw risk score = Sum of detection rule points**

The displayed score is:

**Displayed risk score = Minimum of raw score and 100**

For example, suppose three rules contribute 25, 30, and 20 points.

Raw score:

`25 + 30 + 20 = 75`

Displayed score:

`75`

Using the illustrative thresholds in this document, a score of 75 corresponds to High severity.

If the raw score exceeds 100, the displayed score remains 100. Retaining the raw score separately allows analysts to understand the combined rule contributions.

Important considerations:

- Detection rules should have documented point values.
- Duplicate alerts should not automatically inflate scores without review.
- Confidence should be documented separately from severity.
- Risk scores indicate investigation priority, not proof of compromise.
- Severity thresholds should be validated against project requirements and test data.
- Risk calculations should remain consistent with the existing detection engine.

The visualization module should display risk information supplied by the project's scoring logic rather than silently replacing that logic.

## 5. Evidence Traceability

Evidence traceability means that an analyst can understand why an alert was generated and how it contributed to a user's risk score.

Recommended evidence fields include:

- Event timestamp
- Username
- Hostname
- Source IP address, when available
- Detection rule identifier
- Detection rule name
- Supporting log event identifiers
- Explanation of the detection
- Confidence or evidence-strength label
- Risk points contributed
- Source file and row number, when available

Each displayed finding should be traceable to its underlying event or detection result whenever the source data supports that relationship.

The visualization helpers organize and display the supplied evidence. They do not independently validate the authenticity of the underlying logs or prove that a detection is correct.

Missing evidence should be clearly represented instead of being fabricated or inferred.

## 6. Testing with Synthetic Authentication Logs

The test suite is located at:

`tests/test_mission3.py`

It uses synthetic authentication events to test the visualization helper functions.

The tests cover:

1. Parsing valid timestamps.
2. Handling invalid timestamps.
3. Sorting events chronologically.
4. Ignoring events with invalid timestamps.
5. Calculating user risk scores.
6. Capping displayed risk scores at 100.
7. Building user-to-host graphs.
8. Counting repeated user-to-host events.
9. Grouping related alerts into incidents.
10. Checking incident severity and affected hosts.
11. Ignoring alerts with invalid timestamps.
12. Handling empty input where supported.

### Running the tests

Open a PowerShell terminal in the project root and run:

```powershell
$env:PYTHONPATH = "src"
py -m unittest discover -s tests -p "test_mission3.py" -v
```

A successful run should finish with `OK`.

If a test fails, review the reported assertion and compare the expected output with the actual function implementation.

Passing unit tests verifies the tested helper-function behavior. It does not establish that the entire dashboard or the real detection pipeline works correctly.

## 7. Running the Dashboard

From the project root, run:

```powershell
$env:PYTHONPATH = "src"
py main.py serve --host 127.0.0.1 --port 8072
```

Open the dashboard in a browser:

`http://127.0.0.1:8072`

The dashboard should load its JavaScript and CSS files and contain the appropriate visualization containers.

The JavaScript includes illustrative sample data as a fallback when no backend data object is supplied. When the backend supplies an empty data object, the dashboard should show empty-state messages rather than misleading sample findings.

Actual incident visualization requires connecting the dashboard to the project's real detection and incident data.

### Dashboard verification checklist

- [ ] The dashboard starts without Python errors.
- [ ] The JavaScript file loads successfully.
- [ ] The stylesheet loads successfully.
- [ ] Timeline events appear in chronological order.
- [ ] Timeline filters work correctly.
- [ ] Risk scores and detection-rule contributions appear.
- [ ] The user-to-host graph displays valid connections.
- [ ] Incident cards show the available incident details.
- [ ] Empty or missing data is handled appropriately.
- [ ] The browser console contains no relevant JavaScript errors.
- [ ] Existing file upload, analysis, and export functionality still works.

## 8. Limitations

The starter implementation has the following limitations:

1. Incident grouping uses a basic correlation strategy and may not identify every related alert.
2. Advanced attack-chain correlation is not implemented by the basic grouping approach.
3. Risk thresholds and rule points require validation against the project's approved scoring policy.
4. A user-to-host graph shows recorded relationships, not proof of malicious communication.
5. Evidence quality depends on the underlying logs and detection results.
6. Synthetic data does not represent every real-world authentication scenario.
7. Missing or inconsistent data fields may reduce visualization accuracy.
8. Visualization helpers do not replace the existing detection engine.
9. Unit tests do not replace integration testing of the server and dashboard.
10. Production use requires appropriate access controls, logging, and input validation.
11. Large event collections may require pagination, filtering, or graph-layout optimization.
12. The correctness of the dashboard depends on consistent data formats between Python and JavaScript.

## 9. Future Improvements

Possible improvements include:

- Correlating alerts using source IP addresses and other available indicators.
- Adding time-range, user, host, and severity filters.
- Displaying detailed event evidence when an analyst selects an alert.
- Linking incident cards to the relevant timeline events.
- Adding export functionality for investigation reports.
- Improving graph layout for large numbers of users and hosts.
- Validating risk thresholds against representative labelled data.
- Adding integration tests for the server and dashboard.
- Tracking source event identifiers for stronger evidence traceability.
- Adding pagination for large timelines and incident lists.
- Improving accessibility for keyboard navigation and screen readers.
- Recording visualization errors to help with troubleshooting.

## 10. Conclusion

Mission 3 provides a foundation for investigating authentication activity through timelines, user risk breakdowns, user-to-host graphs, and incident summaries.

Python helper functions prepare data for visualization, while JavaScript renders the dashboard components.

The included unit tests verify selected helper-function behaviors using synthetic data. Before production use, the visualizations should be connected to the actual detection pipeline, the scoring and incident-correlation approaches should be validated, and the complete dashboard should be tested alongside existing application functionality.
