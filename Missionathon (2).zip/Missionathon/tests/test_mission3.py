
"""Tests for Mission 72 Mission 3 visualization helpers."""

import unittest

from mission72.visualizations import (
    parse_timestamp,
    build_timeline,
    build_user_risk_breakdown,
    build_user_host_graph,
    group_alerts_into_incidents,
)


class TestMission3(unittest.TestCase):

    def setUp(self):
        """Create sample authentication events for testing."""

        self.events = [
            {
                "timestamp": "2026-10-17T08:20:00Z",
                "event_type": "Successful login",
                "user": "alex",
                "host": "server-02",
                "status": "suspicious",
                "severity": "high",
                "description": "Successful login after failed attempts",
            },
            {
                "timestamp": "2026-10-17T08:00:00Z",
                "event_type": "Successful login",
                "user": "sam",
                "host": "workstation-01",
                "status": "normal",
                "severity": "low",
                "description": "Normal login",
            },
            {
                "timestamp": "2026-10-17T08:15:00Z",
                "event_type": "Failed login",
                "user": "alex",
                "host": "server-02",
                "status": "suspicious",
                "severity": "medium",
                "description": "Repeated failed login attempts",
            },
        ]

    def test_parse_timestamp(self):
        """Test that a valid timestamp is parsed."""

        result = parse_timestamp("2026-10-17T08:00:00Z")

        self.assertIsNotNone(result)
        self.assertEqual(result.year, 2026)
        self.assertEqual(result.month, 10)
        self.assertEqual(result.day, 17)

    def test_invalid_timestamp(self):
        """Invalid timestamps should return None."""

        self.assertIsNone(parse_timestamp("not-a-timestamp"))

    def test_timeline_chronological_order(self):
        """Events should be sorted from oldest to newest."""

        timeline = build_timeline(self.events)

        self.assertEqual(len(timeline), 3)
        self.assertEqual(
            timeline[0]["event_type"],
            "Successful login",
        )
        self.assertEqual(timeline[0]["user"], "sam")
        self.assertEqual(
            timeline[1]["event_type"],
            "Failed login",
        )
        self.assertEqual(
            timeline[2]["event_type"],
            "Successful login",
        )

    def test_timeline_ignores_invalid_timestamp(self):
        """Events without valid timestamps should be skipped."""

        events = [
            {
                "timestamp": "invalid",
                "user": "alex",
            },
            {
                "timestamp": "2026-10-17T08:00:00Z",
                "user": "sam",
            },
        ]

        timeline = build_timeline(events)

        self.assertEqual(len(timeline), 1)
        self.assertEqual(timeline[0]["user"], "sam")

    def test_user_risk_breakdown(self):
        """Risk points should be combined and capped at 100."""

        rule_hits = [
            {
                "user": "alex",
                "rule_id": "R001",
                "rule_name": "Repeated failed logins",
                "points": 25,
                "confidence": "high",
                "evidence": ["Five failed login attempts"],
                "explanation": "Repeated failures detected",
            },
            {
                "user": "alex",
                "rule_id": "R002",
                "rule_name": "Unusual host access",
                "points": 40,
                "confidence": "medium",
                "evidence": ["Access to server-02"],
                "explanation": "Unusual host access detected",
            },
            {
                "user": "sam",
                "rule_id": "R003",
                "rule_name": "Normal activity",
                "points": 10,
                "confidence": "low",
                "evidence": [],
                "explanation": "Low-risk activity",
            },
        ]

        results = build_user_risk_breakdown(rule_hits)

        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["user"], "alex")
        self.assertEqual(results[0]["score"], 65)
        self.assertEqual(results[0]["severity"], "high")
        self.assertEqual(len(results[0]["contributions"]), 2)

        self.assertEqual(results[1]["user"], "sam")
        self.assertEqual(results[1]["score"], 10)
        self.assertEqual(results[1]["severity"], "low")

    def test_risk_score_is_capped(self):
        """Risk scores should not exceed 100."""

        rule_hits = [
            {"user": "alex", "points": 70},
            {"user": "alex", "points": 60},
        ]

        results = build_user_risk_breakdown(rule_hits)

        self.assertEqual(results[0]["score"], 100)
        self.assertEqual(results[0]["raw_score"], 130)
        self.assertEqual(results[0]["severity"], "critical")

    def test_user_host_graph(self):
        """Graph should contain user nodes, host nodes, and edges."""

        graph = build_user_host_graph(self.events)

        self.assertEqual(len(graph["nodes"]), 4)
        self.assertEqual(len(graph["edges"]), 2)

        user_node_ids = {
            node["id"]
            for node in graph["nodes"]
            if node["type"] == "user"
        }

        host_node_ids = {
            node["id"]
            for node in graph["nodes"]
            if node["type"] == "host"
        }

        self.assertIn("user:alex", user_node_ids)
        self.assertIn("user:sam", user_node_ids)
        self.assertIn("host:server-02", host_node_ids)
        self.assertIn("host:workstation-01", host_node_ids)

        alex_server_edge = next(
            edge for edge in graph["edges"]
            if edge["source"] == "user:alex"
            and edge["target"] == "host:server-02"
        )

        self.assertEqual(alex_server_edge["event_count"], 2)

    def test_group_alerts_into_incidents(self):
        """Related alerts for the same user should be grouped."""

        alerts = [
            {
                "timestamp": "2026-10-17T08:00:00Z",
                "user": "alex",
                "host": "server-01",
                "severity": "medium",
                "event_type": "Failed login",
            },
            {
                "timestamp": "2026-10-17T08:10:00Z",
                "user": "alex",
                "host": "server-02",
                "severity": "high",
                "event_type": "Successful login",
            },
            {
                "timestamp": "2026-10-17T09:00:00Z",
                "user": "alex",
                "host": "server-03",
                "severity": "low",
                "event_type": "Host access",
            },
        ]

        incidents = group_alerts_into_incidents(
            alerts,
            window_minutes=30,
        )

        self.assertEqual(len(incidents), 2)

        first_incident = incidents[0]

        self.assertEqual(first_incident["user"], "alex")
        self.assertEqual(first_incident["severity"], "high")
        self.assertEqual(len(first_incident["alerts"]), 2)

        self.assertIn("server-01", first_incident["affected_hosts"])
        self.assertIn("server-02", first_incident["affected_hosts"])

        self.assertEqual(len(incidents[1]["alerts"]), 1)

    def test_incident_with_invalid_timestamp_is_skipped(self):
        """Alerts with invalid timestamps should not form incidents."""

        alerts = [
            {
                "timestamp": "invalid",
                "user": "alex",
                "severity": "high",
            }
        ]

        incidents = group_alerts_into_incidents(alerts)

        self.assertEqual(incidents, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
