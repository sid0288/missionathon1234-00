
"use strict";

/*
 * Mission 72 - Mission 3 Visualizations
 *
 * Features:
 * 1. Chronological incident timeline
 * 2. Timeline filtering by status and severity
 * 3. User risk breakdown with detection-rule contributions
 * 4. User-to-host communication graph
 * 5. Related incident summaries and alerts
 *
 * No external JavaScript libraries are required.
 *
 * Supported data:
 * window.MISSION72_DATA = {
 *   events: [],
 *   timeline: [],
 *   riskBreakdown: [],
 *   graph: { nodes: [], edges: [] },
 *   incidents: []
 * };
 */

(function () {
    "use strict";

    const sampleData = {
        events: [
            {
                timestamp: "2026-10-17T08:00:00Z",
                event_type: "Successful login",
                user: "alex",
                host: "workstation-01",
                status: "normal",
                severity: "low",
                description: "User logged in from a known workstation."
            },
            {
                timestamp: "2026-10-17T08:15:00Z",
                event_type: "Failed login",
                user: "alex",
                host: "server-02",
                status: "suspicious",
                severity: "medium",
                description: "Several authentication attempts failed."
            },
            {
                timestamp: "2026-10-17T08:20:00Z",
                event_type: "Successful login",
                user: "alex",
                host: "server-02",
                status: "suspicious",
                severity: "high",
                description: "A successful login followed failed attempts."
            },
            {
                timestamp: "2026-10-17T08:25:00Z",
                event_type: "Unusual host access",
                user: "alex",
                host: "server-03",
                status: "suspicious",
                severity: "high",
                description: "The account accessed another host."
            }
        ],

        riskBreakdown: [
            {
                user: "alex",
                score: 75,
                severity: "high",
                contributions: [
                    {
                        rule_id: "R001",
                        rule_name: "Repeated failed logins",
                        points: 25,
                        confidence: "high",
                        evidence: [
                            "Multiple failed authentication events"
                        ],
                        explanation: "Several login attempts failed."
                    },
                    {
                        rule_id: "R002",
                        rule_name: "Successful login after failures",
                        points: 30,
                        confidence: "high",
                        evidence: [
                            "Successful login after failed attempts"
                        ],
                        explanation:
                            "The successful login followed failures."
                    },
                    {
                        rule_id: "R003",
                        rule_name: "Unusual host access",
                        points: 20,
                        confidence: "medium",
                        evidence: ["Access to server-03"],
                        explanation:
                            "The account accessed an additional host."
                    }
                ]
            },
            {
                user: "sam",
                score: 15,
                severity: "low",
                contributions: [
                    {
                        rule_name: "Unusual login time",
                        points: 15,
                        confidence: "low",
                        evidence: ["Login outside usual hours"],
                        explanation:
                            "The login time may warrant review."
                    }
                ]
            }
        ],

        graph: {
            nodes: [
                {
                    id: "user:alex",
                    label: "alex",
                    type: "user"
                },
                {
                    id: "host:workstation-01",
                    label: "workstation-01",
                    type: "host"
                },
                {
                    id: "host:server-02",
                    label: "server-02",
                    type: "host"
                },
                {
                    id: "host:server-03",
                    label: "server-03",
                    type: "host"
                }
            ],
            edges: [
                {
                    source: "user:alex",
                    target: "host:workstation-01",
                    event_count: 1
                },
                {
                    source: "user:alex",
                    target: "host:server-02",
                    event_count: 2
                },
                {
                    source: "user:alex",
                    target: "host:server-03",
                    event_count: 1
                }
            ]
        },

        incidents: [
            {
                incident_id: "INC-001",
                user: "alex",
                severity: "high",
                start_time: "2026-10-17T08:15:00Z",
                end_time: "2026-10-17T08:25:00Z",
                affected_accounts: ["alex"],
                affected_hosts: ["server-02", "server-03"],
                alerts: [
                    {
                        event_type: "Failed login",
                        timestamp: "2026-10-17T08:15:00Z",
                        description:
                            "Several authentication attempts failed.",
                        severity: "medium"
                    },
                    {
                        event_type: "Successful login",
                        timestamp: "2026-10-17T08:20:00Z",
                        description:
                            "A successful login followed failures.",
                        severity: "high"
                    }
                ]
            }
        ]
    };

    // ---------------------------------------------------------
    // Data handling
    // ---------------------------------------------------------

    function getInitialData() {
        const supplied = window.MISSION72_DATA;

        // Use demonstration data only when the backend did not
        // supply the global data object at all.
        if (!supplied || typeof supplied !== "object") {
            return cloneData(sampleData);
        }

        const events = Array.isArray(supplied.events)
            ? supplied.events
            : Array.isArray(supplied.timeline)
                ? supplied.timeline
                : [];

        return {
            events,
            riskBreakdown: Array.isArray(supplied.riskBreakdown)
                ? supplied.riskBreakdown
                : [],
            graph: supplied.graph &&
                Array.isArray(supplied.graph.nodes) &&
                Array.isArray(supplied.graph.edges)
                ? supplied.graph
                : { nodes: [], edges: [] },
            incidents: Array.isArray(supplied.incidents)
                ? supplied.incidents
                : []
        };
    }

    function cloneData(value) {
        return JSON.parse(JSON.stringify(value));
    }

    let data = getInitialData();

    // ---------------------------------------------------------
    // General helper functions
    // ---------------------------------------------------------

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, character => {
            const replacements = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            };

            return replacements[character];
        });
    }

    function getElement(id) {
        return document.getElementById(id);
    }

    /*
     * Support the element IDs from both the original app.js
     * and the alternative dashboard markup.
     */
    function getFirstElement(ids) {
        for (const id of ids) {
            const element = getElement(id);

            if (element) {
                return element;
            }
        }

        return null;
    }

    function setHTML(ids, html) {
        const idList = Array.isArray(ids) ? ids : [ids];
        const element = getFirstElement(idList);

        if (element) {
            element.innerHTML = html;
        }
    }

    function asArray(value) {
        return Array.isArray(value) ? value : [];
    }

    function getUser(event) {
        return event.user ??
            event.username ??
            event.account ??
            event.primary_entity ??
            "Unknown user";
    }

    function getHost(event) {
        return event.host ??
            event.destination_host ??
            event.destination ??
            "Unknown host";
    }

    function getTimestamp(event) {
        return event.timestamp ??
            event.timestamp_utc ??
            event.start_time ??
            null;
    }

    function getEventType(event) {
        return event.event_type ??
            event.title ??
            event.rule_name ??
            "Security event";
    }

    function getDescription(event) {
        return event.description ??
            event.explanation ??
            event.message ??
            "No description available.";
    }

    function getStatus(event) {
        return event.status ??
            event.result ??
            event.outcome ??
            "unknown";
    }

    function parseTime(value) {
        if (!value) {
            return null;
        }

        const date = new Date(value);

        return Number.isNaN(date.getTime()) ? null : date;
    }

    function formatTime(value) {
        const date = parseTime(value);

        if (!date) {
            return "Unknown time";
        }

        return date.toLocaleString();
    }

    function severityClass(value) {
        const normalized = String(value || "low").toLowerCase();

        const allowed = [
            "low",
            "medium",
            "high",
            "critical"
        ];

        return allowed.includes(normalized) ? normalized : "low";
    }

    function normalizeSeverity(value) {
        const normalized = String(value || "").toLowerCase();

        if (normalized === "critical") return "critical";
        if (normalized === "high") return "high";
        if (normalized === "medium") return "medium";
        if (normalized === "low") return "low";

        return "unknown";
    }

    function numericValue(value, fallback = 0) {
        const number = Number(value);

        return Number.isFinite(number) ? number : fallback;
    }

    function renderEmpty(message) {
        return `<p class="m72-empty">${escapeHTML(message)}</p>`;
    }

    // ---------------------------------------------------------
    // Timeline visualization
    // ---------------------------------------------------------

    function renderTimeline(filter = "all") {
        const events = asArray(data.events)
            .filter(event => event && typeof event === "object")
            .map(event => ({
                ...event,
                _parsedTime: parseTime(getTimestamp(event))
            }))
            .filter(event => event._parsedTime !== null)
            .sort((a, b) =>
                a._parsedTime.getTime() - b._parsedTime.getTime()
            );

        const filtered = events.filter(event => {
            const selected = String(filter || "all").toLowerCase();

            if (selected === "all") {
                return true;
            }

            if (selected === "suspicious") {
                return String(getStatus(event)).toLowerCase() ===
                    "suspicious";
            }

            return severityClass(event.severity) === selected;
        });

        if (!filtered.length) {
            setHTML(
                ["m72-timeline", "timeline-container"],
                renderEmpty(
                    events.length
                        ? "No events match this filter."
                        : "No valid timeline events are available."
                )
            );

            return;
        }

        const html = `
            <div class="m72-timeline-list">
                ${filtered.map(event => `
                    <article class="m72-timeline-item">
                        <div class="m72-timeline-marker"
                             aria-hidden="true"></div>

                        <div class="m72-panel">
                            <p class="m72-muted">
                                ${escapeHTML(formatTime(getTimestamp(event)))}
                            </p>

                            <h4>${escapeHTML(getEventType(event))}</h4>

                            <p>${escapeHTML(getDescription(event))}</p>

                            <p>
                                User:
                                <strong>${escapeHTML(getUser(event))}</strong>
                                · Host:
                                <strong>${escapeHTML(getHost(event))}</strong>
                            </p>

                            <span class="m72-badge ${
                                severityClass(event.severity)
                            }">
                                ${escapeHTML(
                                    event.severity || "unknown"
                                )}
                            </span>

                            <span class="m72-badge">
                                ${escapeHTML(getStatus(event))}
                            </span>
                        </div>
                    </article>
                `).join("")}
            </div>
        `;

        setHTML(["m72-timeline", "timeline-container"], html);
    }

    // ---------------------------------------------------------
    // User risk breakdown
    // ---------------------------------------------------------

    function renderRiskBreakdown() {
        const users = asArray(data.riskBreakdown);

        if (!users.length) {
            setHTML(
                ["m72-risk", "risk-breakdown-container"],
                renderEmpty("No user risk data is available.")
            );

            return;
        }

        const html = users.map(user => {
            const score = Math.max(
                0,
                Math.min(100, numericValue(user.score))
            );

            const rawScore = user.raw_score !== undefined
                ? numericValue(user.raw_score)
                : null;

            const contributions = asArray(user.contributions);

            return `
                <article class="m72-panel m72-risk-card">
                    <div class="m72-risk-heading">
                        <h4>${escapeHTML(
                            user.user ?? user.username ?? "Unknown user"
                        )}</h4>

                        <span class="m72-badge ${
                            severityClass(user.severity)
                        }">
                            ${escapeHTML(user.severity || "unknown")}
                        </span>
                    </div>

                    <p>
                        Risk score:
                        <strong>${score}/100</strong>
                    </p>

                    ${
                        rawScore !== null && rawScore > 100
                            ? `<p class="m72-muted">
                                Raw total before cap: ${rawScore}
                               </p>`
                            : ""
                    }

                    <div class="m72-progress-track"
                         role="progressbar"
                         aria-label="Risk score for ${escapeHTML(
                             user.user ?? user.username ?? "Unknown user"
                         )}"
                         aria-valuemin="0"
                         aria-valuemax="100"
                         aria-valuenow="${score}">
                        <div class="m72-progress-fill"
                             style="width: ${score}%"></div>
                    </div>

                    <details>
                        <summary>
                            View detection rule contributions
                            (${contributions.length})
                        </summary>

                        ${
                            contributions.length
                                ? contributions.map(rule => {
                                    const evidence = Array.isArray(
                                        rule.evidence
                                    )
                                        ? rule.evidence.join("; ")
                                        : rule.evidence ?? "No evidence listed";

                                    return `
                                        <div class="m72-contribution">
                                            <strong>
                                                ${escapeHTML(
                                                    rule.rule_name ??
                                                    rule.rule_id ??
                                                    "Detection rule"
                                                )}
                                            </strong>

                                            ${
                                                rule.rule_id
                                                    ? `<p>Rule ID: ${escapeHTML(
                                                        rule.rule_id
                                                    )}</p>`
                                                    : ""
                                            }

                                            <p>
                                                Points:
                                                ${numericValue(rule.points)}
                                            </p>

                                            <p>
                                                Confidence:
                                                ${escapeHTML(
                                                    rule.confidence ?? "unknown"
                                                )}
                                            </p>

                                            <p>
                                                ${escapeHTML(
                                                    rule.explanation ??
                                                    "No explanation available."
                                                )}
                                            </p>

                                            <p>
                                                Evidence:
                                                ${escapeHTML(evidence)}
                                            </p>
                                        </div>
                                    `;
                                }).join("")
                                : renderEmpty(
                                    "No individual rule contributions listed."
                                )
                        }
                    </details>
                </article>
            `;
        }).join("");

        setHTML(["m72-risk", "risk-breakdown-container"], html);
    }

    // ---------------------------------------------------------
    // User-to-host communication graph
    // ---------------------------------------------------------

    function renderGraph() {
        const graph = data.graph || { nodes: [], edges: [] };
        const nodes = asArray(graph.nodes);
        const edges = asArray(graph.edges);

        if (!nodes.length) {
            setHTML(
                ["m72-graph", "communication-graph-container"],
                renderEmpty("No user-to-host graph data is available.")
            );

            return;
        }

        const users = nodes.filter(node => node.type === "user");
        const hosts = nodes.filter(node => node.type === "host");

        const otherNodes = nodes.filter(
            node => node.type !== "user" && node.type !== "host"
        );

        const width = 760;
        const rowHeight = 90;
        const height = Math.max(
            280,
            (Math.max(users.length, hosts.length, otherNodes.length) + 1) *
                rowHeight
        );

        const leftX = 160;
        const rightX = 600;
        const centerX = width / 2;
        const positions = Object.create(null);

        users.forEach((node, index) => {
            positions[node.id] = {
                x: leftX,
                y: height * (index + 1) / (users.length + 1)
            };
        });

        hosts.forEach((node, index) => {
            positions[node.id] = {
                x: rightX,
                y: height * (index + 1) / (hosts.length + 1)
            };
        });

        otherNodes.forEach((node, index) => {
            positions[node.id] = {
                x: centerX,
                y: height * (index + 1) / (otherNodes.length + 1)
            };
        });

        const validEdges = edges.filter(edge =>
            edge &&
            positions[edge.source] &&
            positions[edge.target]
        );

        const lines = validEdges.map(edge => {
            const source = positions[edge.source];
            const target = positions[edge.target];

            const eventCount = Math.max(
                1,
                numericValue(edge.event_count ?? edge.weight, 1)
            );

            const strokeWidth = Math.min(
                7,
                1 + Math.log2(eventCount + 1)
            );

            return `
                <line
                    x1="${source.x}"
                    y1="${source.y}"
                    x2="${target.x}"
                    y2="${target.y}"
                    stroke="currentColor"
                    stroke-opacity="0.45"
                    stroke-width="${strokeWidth}"
                />
            `;
        }).join("");

        const circles = nodes.map(node => {
            const position = positions[node.id];

            if (!position) {
                return "";
            }

            const isUser = node.type === "user";
            const fill = isUser ? "#2563eb" : "#0d9488";

            return `
                <g>
                    <circle
                        cx="${position.x}"
                        cy="${position.y}"
                        r="9"
                        fill="${fill}"
                    />

                    <text
                        x="${position.x}"
                        y="${position.y - 17}"
                        text-anchor="middle"
                        font-size="12"
                        fill="currentColor"
                    >${escapeHTML(node.label ?? node.id)}</text>
                </g>
            `;
        }).join("");

        const html = `
            <p class="m72-muted">
                Blue nodes represent users. Teal nodes represent hosts.
                Thicker lines represent more recorded events.
            </p>

            <div class="m72-graph-scroll">
                <svg
                    viewBox="0 0 ${width} ${height}"
                    role="img"
                    aria-label="User-to-host communication graph"
                    class="m72-graph-svg"
                >
                    ${lines}
                    ${circles}
                </svg>
            </div>

            <div class="m72-graph-legend">
                <span>
                    <span class="m72-legend-dot m72-user-dot"></span>
                    Users: ${users.length}
                </span>

                <span>
                    <span class="m72-legend-dot m72-host-dot"></span>
                    Hosts: ${hosts.length}
                </span>

                <span>Connections: ${validEdges.length}</span>
            </div>
        `;

        setHTML(
            ["m72-graph", "communication-graph-container"],
            html
        );
    }

    // ---------------------------------------------------------
    // Related incidents
    // ---------------------------------------------------------

    function renderIncidents() {
        const incidents = asArray(data.incidents);

        if (!incidents.length) {
            setHTML(
                ["m72-incidents", "visualized-incidents-container"],
                renderEmpty("No related incidents are available.")
            );

            return;
        }

        const html = incidents.map((incident, index) => {
            const incidentId =
                incident.incident_id ??
                incident.id ??
                `INC-${String(index + 1).padStart(3, "0")}`;

            const accounts = asArray(
                incident.affected_accounts ??
                incident.affected_users
            );

            if (!accounts.length && incident.user) {
                accounts.push(incident.user);
            }

            const hosts = asArray(incident.affected_hosts);

            const alerts = asArray(
                incident.alerts ??
                incident.evidence
            );

            const startTime =
                incident.start_time ??
                incident.start_time_utc ??
                incident.start;

            const endTime =
                incident.end_time ??
                incident.end_time_utc ??
                incident.end;

            return `
                <article class="m72-panel m72-incident-card">
                    <div class="m72-risk-heading">
                        <h4>${escapeHTML(incidentId)}</h4>

                        <span class="m72-badge ${
                            severityClass(incident.severity)
                        }">
                            ${escapeHTML(incident.severity || "unknown")}
                        </span>
                    </div>

                    <p>
                        Account:
                        ${escapeHTML(
                            accounts.join(", ") ||
                            incident.primary_entity ||
                            "Unknown"
                        )}
                    </p>

                    <p>
                        Hosts:
                        ${escapeHTML(
                            hosts.join(", ") || "None listed"
                        )}
                    </p>

                    <p>
                        Start:
                        ${escapeHTML(formatTime(startTime))}
                    </p>

                    <p>
                        End:
                        ${escapeHTML(formatTime(endTime))}
                    </p>

                    ${
                        incident.title
                            ? `<p>${escapeHTML(incident.title)}</p>`
                            : ""
                    }

                    <details>
                        <summary>
                            View related alerts (${alerts.length})
                        </summary>

                        ${
                            alerts.length
                                ? alerts.map(alert => `
                                    <div class="m72-contribution">
                                        <strong>
                                            ${escapeHTML(
                                                getEventType(alert)
                                            )}
                                        </strong>

                                        <p>
                                            ${escapeHTML(
                                                formatTime(
                                                    getTimestamp(alert)
                                                )
                                            )}
                                        </p>

                                        <p>
                                            ${escapeHTML(
                                                getDescription(alert)
                                            )}
                                        </p>

                                        <span class="m72-badge ${
                                            severityClass(alert.severity)
                                        }">
                                            ${escapeHTML(
                                                alert.severity || "unknown"
                                            )}
                                        </span>
                                    </div>
                                `).join("")
                                : renderEmpty(
                                    "No individual alerts are listed."
                                )
                        }
                    </details>
                </article>
            `;
        }).join("");

        setHTML(
            ["m72-incidents", "visualized-incidents-container"],
            html
        );
    }

    // ---------------------------------------------------------
    // Timeline controls
    // ---------------------------------------------------------

    function bindControls() {
        const filter = getFirstElement([
            "m72-timeline-filter",
            "timeline-filter"
        ]);

        if (filter && filter.dataset.m72Bound !== "true") {
            filter.addEventListener("change", () => {
                renderTimeline(filter.value);
            });

            filter.dataset.m72Bound = "true";
        }
    }

    // ---------------------------------------------------------
    // Public rendering API
    // ---------------------------------------------------------

    function renderAll() {
        renderTimeline();
        renderRiskBreakdown();
        renderGraph();
        renderIncidents();
        bindControls();
    }

    function updateData(newData) {
        const supplied = newData && typeof newData === "object"
            ? newData
            : {};

        const events = Array.isArray(supplied.events)
            ? supplied.events
            : Array.isArray(supplied.timeline)
                ? supplied.timeline
                : [];

        data = {
            events,
            riskBreakdown: asArray(supplied.riskBreakdown),
            graph: supplied.graph &&
                Array.isArray(supplied.graph.nodes) &&
                Array.isArray(supplied.graph.edges)
                ? supplied.graph
                : { nodes: [], edges: [] },
            incidents: asArray(supplied.incidents)
        };

        renderAll();
    }

    const Mission72Visuals = {
        renderAll,
        renderTimeline,
        renderRiskBreakdown,
        renderGraph,
        renderIncidents,
        updateData
    };

    window.Mission72Visuals = Mission72Visuals;

    function initialize() {
        renderAll();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initialize, {
            once: true
        });
    } else {
        initialize();
    }
})();
