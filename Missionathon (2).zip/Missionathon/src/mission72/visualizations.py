
"""Data preparation helpers for Mission 72 Mission 3 visualizations."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


SEVERITY_ORDER = {
    "low": 1,
    "medium": 2,
    "moderate": 2,
    "high": 3,
    "critical": 4,
}


def parse_timestamp(value: Any) -> Optional[datetime]:
    """Parse a timestamp into a timezone-aware datetime.

    Accepts datetime objects and ISO-8601 strings, including strings
    ending in 'Z'. Returns None when the value is missing or invalid.
    """
    if value is None:
        return None

    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        value = value.strip()

        if not value:
            return None

        try:
            parsed = datetime.fromisoformat(
                value.replace("Z", "+00:00")
            )
        except ValueError:
            return None
    else:
        return None

    # Treat timestamps without timezone information as UTC.
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)

    return parsed


def _timestamp_from_record(record: Dict[str, Any]) -> Optional[datetime]:
    """Read a timestamp from common event and alert field names."""
    for field in (
        "timestamp",
        "timestamp_utc",
        "event_timestamp",
        "start_time",
        "start_time_utc",
    ):
        if field in record:
            parsed = parse_timestamp(record[field])
            if parsed is not None:
                return parsed

    return None


def _get_user(record: Dict[str, Any]) -> str:
    """Return the username from common field names."""
    value = (
        record.get("user")
        or record.get("username")
        or record.get("account")
        or record.get("user_id")
    )

    return str(value).strip() if value is not None else ""


def _get_host(record: Dict[str, Any]) -> str:
    """Return the hostname from common field names."""
    value = (
        record.get("host")
        or record.get("hostname")
        or record.get("destination_host")
        or record.get("destination")
    )

    return str(value).strip() if value is not None else ""


def _severity(record: Dict[str, Any]) -> str:
    """Return a normalized severity label."""
    value = str(record.get("severity") or "low").strip().lower()

    if value == "moderate":
        return "medium"

    if value in SEVERITY_ORDER:
        return value

    return "low"


def build_timeline(events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return a chronologically sorted copy of valid events.

    Events with missing or invalid timestamps are omitted.
    The input list and its dictionaries are not modified.
    """
    valid_events = []

    for event in events or []:
        if not isinstance(event, dict):
            continue

        timestamp = _timestamp_from_record(event)

        if timestamp is None:
            continue

        valid_events.append((timestamp, dict(event)))

    # Python sorting is stable, so events with equal timestamps retain
    # their original relative order.
    valid_events.sort(key=lambda item: item[0])

    return [event for _, event in valid_events]


def build_user_risk_breakdown(
    rule_hits: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Aggregate detection-rule points for each user.

    Each rule hit may contain:
        user, rule_id, rule_name, points, confidence, evidence,
        explanation, severity

    The raw score is the sum of rule points. The displayed score is
    capped at 100. Severity is derived from the displayed score using
    the thresholds documented below.
    """
    users: Dict[str, Dict[str, Any]] = {}

    for hit in rule_hits or []:
        if not isinstance(hit, dict):
            continue

        user = _get_user(hit)

        if not user:
            continue

        try:
            points = float(hit.get("points", 0))
        except (TypeError, ValueError):
            points = 0

        # Risk points should not be negative or non-finite.
        if points < 0 or points != points or points in (
            float("inf"),
            float("-inf"),
        ):
            points = 0

        if user not in users:
            users[user] = {
                "user": user,
                "raw_score": 0,
                "contributions": [],
            }

        users[user]["raw_score"] += points

        users[user]["contributions"].append(
            {
                "rule_id": hit.get("rule_id", ""),
                "rule_name": hit.get(
                    "rule_name",
                    hit.get("name", "Unnamed detection rule"),
                ),
                "points": points,
                "confidence": hit.get("confidence", "unknown"),
                "evidence": list(hit.get("evidence") or [])
                if isinstance(hit.get("evidence") or [], (list, tuple))
                else [hit.get("evidence")],
                "explanation": hit.get("explanation", ""),
            }
        )

    result = []

    for user_data in users.values():
        raw_score = user_data["raw_score"]
        score = min(100, round(raw_score))

        if score < 30:
            severity = "low"
        elif score < 60:
            severity = "medium"
        elif score < 80:
            severity = "high"
        else:
            severity = "critical"

        result.append(
            {
                "user": user_data["user"],
                "score": score,
                "raw_score": round(raw_score, 2),
                "severity": severity,
                "contributions": user_data["contributions"],
            }
        )

    result.sort(
        key=lambda item: (-item["score"], item["user"].lower())
    )

    return result


def build_user_host_graph(
    events: List[Dict[str, Any]],
) -> Dict[str, List[Dict[str, Any]]]:
    """Build user and host nodes with counts for observed connections.

    Events without both a username and hostname are ignored.

    Returns:
        {
            "nodes": [
                {"id": "user:alex", "label": "alex", "type": "user"},
                {
                    "id": "host:server-02",
                    "label": "server-02",
                    "type": "host",
                },
            ],
            "edges": [
                {
                    "source": "user:alex",
                    "target": "host:server-02",
                    "event_count": 2,
                }
            ],
        }
    """
    nodes: Dict[str, Dict[str, str]] = {}
    edge_counts: Dict[tuple, int] = {}

    for event in events or []:
        if not isinstance(event, dict):
            continue

        user = _get_user(event)
        host = _get_host(event)

        if not user or not host:
            continue

        user_id = f"user:{user}"
        host_id = f"host:{host}"

        nodes[user_id] = {
            "id": user_id,
            "label": user,
            "type": "user",
        }

        nodes[host_id] = {
            "id": host_id,
            "label": host,
            "type": "host",
        }

        edge = (user_id, host_id)
        edge_counts[edge] = edge_counts.get(edge, 0) + 1

    ordered_nodes = sorted(
        nodes.values(),
        key=lambda node: (node["type"], node["label"].lower()),
    )

    ordered_edges = [
        {
            "source": source,
            "target": target,
            "event_count": count,
        }
        for (source, target), count in sorted(edge_counts.items())
    ]

    return {
        "nodes": ordered_nodes,
        "edges": ordered_edges,
    }


def group_alerts_into_incidents(
    alerts: List[Dict[str, Any]],
    window_minutes: int = 30,
) -> List[Dict[str, Any]]:
    """Group alerts for the same user when they fall within a time window.

    Alerts are sorted chronologically first. A new incident starts when
    the user changes or the gap from the previous alert for that user
    exceeds the configured window.

    Alerts with invalid timestamps or no username are skipped.
    """
    if window_minutes < 0:
        raise ValueError("window_minutes must be zero or greater")

    valid_alerts = []

    for alert in alerts or []:
        if not isinstance(alert, dict):
            continue

        timestamp = _timestamp_from_record(alert)
        user = _get_user(alert)

        if timestamp is None or not user:
            continue

        valid_alerts.append((timestamp, dict(alert), user))

    valid_alerts.sort(key=lambda item: item[0])

    incidents = []
    current_incident = None
    previous_timestamp = None
    previous_user = None
    window_seconds = window_minutes * 60

    for timestamp, alert, user in valid_alerts:
        start_new_incident = (
            current_incident is None
            or user != previous_user
            or previous_timestamp is None
            or (timestamp - previous_timestamp).total_seconds()
            > window_seconds
        )

        if start_new_incident:
            current_incident = {
                "user": user,
                "severity": _severity(alert),
                "start_time": timestamp.isoformat(),
                "end_time": timestamp.isoformat(),
                "alerts": [],
                "affected_hosts": [],
            }
            incidents.append(current_incident)

        current_incident["alerts"].append(alert)
        current_incident["end_time"] = timestamp.isoformat()

        current_severity = _severity(alert)

        if (
            SEVERITY_ORDER[current_severity]
            > SEVERITY_ORDER[current_incident["severity"]]
        ):
            current_incident["severity"] = current_severity

        host = _get_host(alert)

        if host and host not in current_incident["affected_hosts"]:
            current_incident["affected_hosts"].append(host)

        previous_timestamp = timestamp
        previous_user = user

    return incidents
