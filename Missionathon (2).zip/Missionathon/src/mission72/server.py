"""
Mission 72 — Authentication Threat Investigation Dashboard.

Features:
- CSV upload and analysis
- Synthetic benchmark loading
- Incident filtering and evidence inspection
- User risk profiles
- Mission 3 timeline and user-to-host graph
- CSV and HTML report exports

Run from the project root:
    $env:PYTHONPATH = "src"
    py main.py serve --host 127.0.0.1 --port 8072
"""

import email
import io
import json
import os
import re
import urllib.parse
from email.policy import default as email_default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from mission72.baseline import build_user_baselines
from mission72.context import ContextRegistry, create_default_context_registry
from mission72.detections import DetectionEngine
from mission72.incidents import (
    compute_user_risk_profiles,
    group_alerts_into_incidents,
)
from mission72.ingestion import parse_csv_stream
from mission72.reporting import (
    generate_evidence_csv,
    generate_html_report,
    generate_incidents_csv,
    generate_user_risk_csv,
)
from mission72.visualizations import (
    build_timeline,
    build_user_host_graph,
)


# ---------------------------------------------------------------------
# Configuration and application state
# ---------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
STATIC_DIR = Path(__file__).resolve().parent / "static"
MAX_UPLOAD_BYTES = 50 * 1024 * 1024


def get_active_context_registry() -> ContextRegistry:
    """Load context configuration or use the default registry."""
    config_path = PROJECT_ROOT / "config" / "context_config.json"

    if config_path.exists():
        try:
            return ContextRegistry.from_file(config_path)
        except Exception as exc:
            print(f"Warning: could not load context configuration: {exc}")

    return create_default_context_registry()


class InvestigatorState:
    """In-memory state for the current dashboard session."""

    def __init__(self):
        self.incidents = []
        self.user_profiles = []
        self.quality_report = None
        self.training_events_count = 0
        self.evaluation_events_count = 0


GLOBAL_STATE = InvestigatorState()


def safe_json(value: Any) -> str:
    """Serialize data safely for insertion into an HTML script."""
    return (
        json.dumps(value, ensure_ascii=False, default=str)
        .replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
    )


def evidence_to_dict(ev) -> Dict[str, Any]:
    """Convert an evidence record into dashboard-friendly fields."""
    return {
        "source": f"{Path(ev.source_file).name}:{ev.row_number}",
        "timestamp": str(ev.timestamp_utc),
        "username": ev.username,
        "source_ip": ev.source_ip,
        "dest": ev.destination_host,
        "destination_host": ev.destination_host,
        "event_type": ev.event_type,
        "result": ev.result,
        "logon_type": ev.logon_type,
        "row_number": ev.row_number,
    }


def build_dashboard_incidents() -> list:
    """Prepare the existing incident objects for the browser."""
    result = []

    for incident in GLOBAL_STATE.incidents:
        result.append({
            "id": incident.incident_id,
            "title": incident.title,
            "severity": incident.severity,
            "score": incident.risk_score,
            "entity": incident.primary_entity,
            "start": incident.start_time_utc.strftime("%Y-%m-%d %H:%M"),
            "end": incident.end_time_utc.strftime("%Y-%m-%d %H:%M UTC"),
            "categories": incident.categories or [],
            "rule_ids": incident.rule_ids or [],
            "context_status": getattr(incident, "context_status", "NONE"),
            "context_summary": getattr(incident, "context_summary", ""),
            "recommended_action": incident.recommended_action,
            "risk_explanation": incident.risk_explanation,
            "evidence": [
                evidence_to_dict(ev)
                for ev in incident.evidence_records
            ],
        })

    return result


def build_visualization_payload() -> Dict[str, Any]:
    """Build Mission 3 visualizations from actual incident evidence."""
    evidence_events = []

    for incident in GLOBAL_STATE.incidents:
        for ev in incident.evidence_records:
            evidence_events.append({
                "timestamp": ev.timestamp_utc,
                "username": ev.username,
                "source_ip": ev.source_ip,
                "destination_host": ev.destination_host,
                "event_type": ev.event_type,
                "result": ev.result,
                "logon_type": ev.logon_type,
                "source": Path(ev.source_file).name,
                "row_number": ev.row_number,
            })

    # These helpers use the visualization module already in your project.
    timeline = build_timeline(evidence_events)
    graph = build_user_host_graph(evidence_events)

    # Use the real profiles and incident rule IDs. Do not calculate a
    # second risk score or invent detection-rule contributions.
    risk_breakdown = []

    for profile in GLOBAL_STATE.user_profiles:
        username = getattr(profile, "username", "")
        triggered_rules = getattr(profile, "rules_triggered", []) or []

        related_incidents = [
            incident
            for incident in GLOBAL_STATE.incidents
            if any(
                ev.username == username
                for ev in incident.evidence_records
            )
        ]

        for rule_id in triggered_rules:
            matching = [
                incident
                for incident in related_incidents
                if rule_id in (incident.rule_ids or [])
            ]

            risk_breakdown.append({
                "username": username,
                "risk_score": getattr(profile, "risk_score", None),
                "severity": getattr(profile, "highest_severity", ""),
                "rule_id": rule_id,
                "incidents": [
                    incident.incident_id
                    for incident in matching
                ],
                "evidence_source": [
                    f"{Path(ev.source_file).name}:{ev.row_number}"
                    for incident in matching
                    for ev in incident.evidence_records
                    if ev.username == username
                ],
            })

    incident_summary = [
        {
            "id": incident.incident_id,
            "title": incident.title,
            "severity": incident.severity,
            "score": incident.risk_score,
            "entity": incident.primary_entity,
            "start": incident.start_time_utc.strftime("%Y-%m-%d %H:%M:%S"),
            "rule_ids": incident.rule_ids or [],
        }
        for incident in GLOBAL_STATE.incidents
    ]

    return {
        "timeline": timeline,
        "riskBreakdown": risk_breakdown,
        "graph": graph,
        "incidents": incident_summary,
    }


# ---------------------------------------------------------------------
# Dashboard HTML
# ---------------------------------------------------------------------

SERVER_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mission 72 — Threat Investigation</title>
<link rel="stylesheet" href="/static/styles.css">
<style>
:root {
  color-scheme: dark;
  --bg: #0d1117;
  --surface: #161b27;
  --surface2: #1c2333;
  --border: #30363d;
  --text: #e6edf3;
  --muted: #91a0b4;
  --accent: #3b82f6;
  --danger: #f85149;
  --high: #f0883e;
  --medium: #d29922;
  --success: #3fb950;
}
* { box-sizing: border-box; }
body {
  margin: 0;
  background: var(--bg);
  color: var(--text);
  font: 14px/1.5 system-ui, sans-serif;
}
.app-shell { max-width: 1500px; margin: auto; padding: 20px; }
header { padding-bottom: 15px; border-bottom: 1px solid var(--border); }
h1 { font-size: 21px; margin: 0; }
h2 { font-size: 18px; margin: 22px 0 10px; }
h3 { font-size: 14px; margin: 0 0 10px; }
button, input, select { font: inherit; }
button, .button-link {
  background: var(--accent); color: white; border: 0;
  border-radius: 6px; padding: 9px 13px; cursor: pointer;
  text-decoration: none; display: inline-block;
}
button:disabled { opacity: .6; cursor: wait; }
input, select {
  background: var(--bg); color: var(--text);
  border: 1px solid var(--border); border-radius: 6px;
  padding: 8px;
}
.panel {
  margin-top: 16px; padding: 16px;
  border: 1px solid var(--border); border-radius: 10px;
  background: var(--surface);
}
.upload-grid, .visual-grid {
  display: grid; grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}
.upload-field { padding: 12px; border: 1px solid var(--border); border-radius: 8px; }
.upload-field label { display: block; font-weight: 600; margin-bottom: 8px; }
.upload-actions, .filters, .exports {
  display: flex; flex-wrap: wrap; align-items: center; gap: 10px;
  margin-top: 14px;
}
.muted, .hint { color: var(--muted); font-size: 12px; }
.summary {
  display: grid; grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 12px; margin-top: 16px;
}
.stat { padding: 14px; background: var(--surface); border: 1px solid var(--border); border-radius: 8px; }
.stat-value { display: block; font-size: 25px; font-weight: 700; }
.stat-label { color: var(--muted); font-size: 10px; text-transform: uppercase; }
.workspace { display: flex; align-items: flex-start; margin-top: 14px; }
.table-area { min-width: 0; flex: 1; overflow: auto; }
table { border-collapse: collapse; width: 100%; font-size: 12px; }
th, td { padding: 9px; text-align: left; border-bottom: 1px solid var(--border); }
th { color: var(--muted); background: var(--surface2); }
tbody tr[data-id] { cursor: pointer; }
tbody tr[data-id]:hover { background: var(--surface2); }
.detail-panel {
  display: none; width: 420px; min-width: 320px; max-height: 80vh;
  overflow: auto; padding: 16px; border: 1px solid var(--border);
  background: var(--surface); border-radius: 8px;
}
.section { border-top: 1px solid var(--border); margin-top: 12px; padding-top: 12px; }
.badge { display: inline-block; padding: 2px 7px; margin: 2px; border-radius: 4px; background: #1e2a4a; }
.visual-grid { margin-top: 12px; }
.visual-card { min-width: 0; overflow: auto; }
.visual-card.wide { grid-column: 1 / -1; }
.visual-card table { min-width: 400px; }
.empty { padding: 24px 10px; color: var(--muted); }
a.secondary { background: transparent; border: 1px solid var(--border); }
pre { white-space: pre-wrap; overflow-wrap: anywhere; }
@media (max-width: 900px) {
  .workspace { display: block; }
  .detail-panel { width: 100%; margin-top: 12px; max-height: none; }
}
@media (max-width: 650px) {
  .app-shell { padding: 12px; }
  .upload-grid, .visual-grid, .summary { grid-template-columns: 1fr; }
  .visual-card.wide { grid-column: auto; }
}
</style>
</head>
<body>
<div class="app-shell">
<header>
  <h1>Mission 72 <span class="muted">— Authentication Threat Investigation</span></h1>
</header>

<section class="panel">
  <details id="upload-details">
    <summary>Analyze new logs</summary>
    <form id="analyze-form" action="/analyze" method="POST"
          enctype="multipart/form-data">
      <div class="upload-grid" style="margin-top:14px">
        <div class="upload-field">
          <label for="train_file">Training CSV (optional)</label>
          <input type="file" id="train_file" name="train_file" accept=".csv">
          <p class="hint">Used to establish normal user behavior.</p>
        </div>
        <div class="upload-field">
          <label for="eval_file">Evaluation CSV (required)</label>
          <input type="file" id="eval_file" name="eval_file" accept=".csv" required>
          <p class="hint">Authentication activity to investigate.</p>
        </div>
      </div>
      <div class="upload-actions">
        <button type="submit" id="submit-btn">Analyze logs</button>
        <a class="button-link secondary" href="/analyze-synthetic">Load synthetic benchmark</a>
      </div>
      <p id="upload-error" role="alert"></p>
    </form>
  </details>
</section>

<div id="summary-bar" class="summary" style="display:none">
  <div class="stat"><span id="st-total" class="stat-value">0</span><span class="stat-label">Incidents</span></div>
  <div class="stat"><span id="st-crithigh" class="stat-value">0</span><span class="stat-label">Critical / High</span></div>
  <div class="stat"><span id="st-maxscore" class="stat-value">0</span><span class="stat-label">Highest score</span></div>
  <div class="stat"><span id="st-users" class="stat-value">0</span><span class="stat-label">Profiled users</span></div>
</div>

<div id="filter-bar" class="panel filters" style="display:none">
  <input type="search" id="q-entity" placeholder="Search entity, user, or IP" aria-label="Search incidents">
  <select id="q-sev" aria-label="Severity filter">
    <option value="ALL">All severities</option>
    <option value="CRITICAL">Critical</option>
    <option value="HIGH">High</option>
    <option value="MEDIUM">Medium</option>
    <option value="LOW">Low</option>
  </select>
  <input type="number" id="q-score" min="0" max="100" value="0" aria-label="Minimum score">
  <button id="reset-filters" type="button">Reset filters</button>
  <span class="muted" id="filter-count"></span>
</div>

<div class="workspace">
  <section class="table-area panel" id="table-area">
    <div id="empty-state" class="empty">
      <h2>No analysis loaded</h2>
      Upload a CSV or load the synthetic benchmark to begin.
    </div>
    <div id="table-container" style="display:none">
      <table>
        <thead><tr>
          <th>Severity</th><th>Incident</th><th>Entity</th>
          <th>Score</th><th>Start (UTC)</th><th>Categories</th>
        </tr></thead>
        <tbody id="incident-tbody"></tbody>
      </table>
    </div>
  </section>

  <aside class="detail-panel" id="detail-panel" aria-label="Incident details">
    <button type="button" id="close-panel" style="float:right">Close</button>
    <div class="muted" id="p-id"></div>
    <div id="p-score" style="font-size:38px;font-weight:800"></div>
    <h3 id="p-title"></h3>
    <div class="section"><div class="muted">Entity</div><div id="p-entity"></div></div>
    <div class="section"><div class="muted">Time range</div><div id="p-time"></div></div>
    <div class="section"><div class="muted">Detection rules</div><div id="p-rules"></div></div>
    <div class="section"><div class="muted">Categories</div><div id="p-cats"></div></div>
    <div class="section"><div class="muted">Context status</div><div id="p-context-badge"></div><p id="p-context-summary"></p></div>
    <div class="section"><div class="muted">Recommended action</div><p id="p-action"></p></div>
    <details class="section">
      <summary>Technical details and supporting evidence</summary>
      <pre id="p-explanation"></pre>
      <div style="overflow:auto">
        <table>
          <thead><tr><th>Source</th><th>Timestamp</th><th>User</th><th>IP</th><th>Host</th><th>Event</th><th>Result</th></tr></thead>
          <tbody id="p-ev-body"></tbody>
        </table>
      </div>
    </details>
  </aside>
</div>

<section id="mission3-visualizations">
  <h2>Mission 3 — Investigation Visualizations</h2>
  <p class="muted">These views use evidence and risk profiles from the current analysis.</p>
  <div class="visual-grid">
    <section class="panel visual-card">
      <h3>Incident Timeline</h3>
      <div id="timeline-container" class="empty">Load an analysis to see timeline events.</div>
    </section>
    <section class="panel visual-card">
      <h3>User Risk Breakdown</h3>
      <div id="risk-breakdown-container" class="empty">Load an analysis to see rule evidence.</div>
    </section>
    <section class="panel visual-card wide">
      <h3>User-to-Host Communication Graph</h3>
      <div id="communication-graph-container" class="empty">Load an analysis to see connections.</div>
    </section>
    <section class="panel visual-card wide">
      <h3>Related Incidents</h3>
      <div id="visualized-incidents-container" class="empty">Load an analysis to see incident groups.</div>
    </section>
  </div>
</section>

<details class="panel">
  <summary>Download reports</summary>
  <div class="exports">
    <a class="button-link secondary" href="/export/incidents.csv">Incidents CSV</a>
    <a class="button-link secondary" href="/export/evidence.csv">Evidence CSV</a>
    <a class="button-link secondary" href="/export/users.csv">User Risk CSV</a>
    <a class="button-link secondary" href="/export/report.html" target="_blank" rel="noopener">Full HTML report</a>
  </div>
</details>
</div>

<script>
const INCIDENTS = __INCIDENT_JSON__;
const METRICS = __METRICS_JSON__;
const HAS_RESULTS = __HAS_RESULTS__;
window.MISSION72_DATA = __VISUALIZATION_JSON__;

const $ = id => document.getElementById(id);
const text = (id, value) => {
  const el = $(id);
  if (el) el.textContent = value == null ? "" : String(value);
};
const severityColor = severity => ({
  CRITICAL: "#f85149",
  HIGH: "#f0883e",
  MEDIUM: "#d29922",
  LOW: "#91a0b4"
}[severity] || "#91a0b4");

function renderBadges(id, values) {
  const root = $(id);
  root.replaceChildren();
  (values || []).forEach(value => {
    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = String(value);
    root.appendChild(badge);
  });
}

function renderIncidents() {
  const tbody = $("incident-tbody");
  tbody.replaceChildren();

  INCIDENTS.forEach(incident => {
    const row = document.createElement("tr");
    row.dataset.id = incident.id;
    row.dataset.severity = incident.severity;
    row.dataset.score = incident.score;
    row.dataset.search = [
      incident.entity,
      incident.title,
      ...(incident.evidence || []).map(ev => ev.source_ip || "")
    ].join(" ").toLowerCase();

    const values = [
      incident.severity,
      incident.title,
      incident.entity,
      incident.score,
      incident.start,
      (incident.categories || []).join(", ")
    ];

    values.forEach((value, index) => {
      const cell = document.createElement("td");
      cell.textContent = value == null ? "" : String(value);
      if (index === 0) {
        cell.style.color = severityColor(incident.severity);
        cell.style.fontWeight = "700";
      }
      row.appendChild(cell);
    });

    row.tabIndex = 0;
    row.setAttribute("role", "button");
    row.addEventListener("click", () => openIncident(incident.id));
    row.addEventListener("keydown", event => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openIncident(incident.id);
      }
    });
    tbody.appendChild(row);
  });
}

function openIncident(id) {
  const incident = INCIDENTS.find(item => item.id === id);
  if (!incident) return;

  text("p-id", incident.id);
  text("p-score", incident.score);
  $("p-score").style.color = severityColor(incident.severity);
  text("p-title", incident.title);
  text("p-entity", incident.entity);
  text("p-time", incident.start + " — " + incident.end);
  text("p-context-summary", incident.context_summary || "No additional context summary.");
  text("p-action", incident.recommended_action);
  text("p-explanation", incident.risk_explanation);

  renderBadges("p-rules", incident.rule_ids);
  renderBadges("p-cats", incident.categories);
  renderBadges("p-context-badge", [incident.context_status || "NONE"]);

  const tbody = $("p-ev-body");
  tbody.replaceChildren();

  (incident.evidence || []).forEach(ev => {
    const row = document.createElement("tr");
    [
      ev.source, ev.timestamp, ev.username, ev.source_ip,
      ev.dest, ev.event_type, ev.result
    ].forEach(value => {
      const cell = document.createElement("td");
      cell.textContent = value || "";
      row.appendChild(cell);
    });
    tbody.appendChild(row);
  });

  $("detail-panel").style.display = "block";
}

function applyFilters() {
  const query = $("q-entity").value.toLowerCase().trim();
  const severity = $("q-sev").value;
  const minScore = Number($("q-score").value || 0);
  let visible = 0;

  document.querySelectorAll("#incident-tbody tr[data-id]").forEach(row => {
    const matches =
      (!query || row.dataset.search.includes(query)) &&
      (severity === "ALL" || row.dataset.severity === severity) &&
      Number(row.dataset.score) >= minScore;

    row.style.display = matches ? "" : "none";
    if (matches) visible++;
  });

  text("filter-count", `${visible} of ${INCIDENTS.length} incidents`);
}

function renderTable(containerId, headers, rows) {
  const root = $(containerId);
  root.replaceChildren();

  if (!rows || !rows.length) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "No supporting data is available for this view.";
    root.appendChild(empty);
    return;
  }

  const table = document.createElement("table");
  const thead = document.createElement("thead");
  const headerRow = document.createElement("tr");

  headers.forEach(header => {
    const th = document.createElement("th");
    th.textContent = header;
    headerRow.appendChild(th);
  });

  thead.appendChild(headerRow);
  table.appendChild(thead);

  const tbody = document.createElement("tbody");
  rows.forEach(values => {
    const row = document.createElement("tr");
    values.forEach(value => {
      const cell = document.createElement("td");
      cell.textContent = value == null ? "" : String(value);
      row.appendChild(cell);
    });
    tbody.appendChild(row);
  });

  table.appendChild(tbody);
  root.appendChild(table);
}

function renderVisualizations(data) {
  const timeline = data.timeline || [];
  renderTable(
    "timeline-container",
    ["Timestamp", "User", "Source IP", "Destination host", "Event", "Result"],
    timeline.map(event => [
      event.timestamp || event.time || "",
      event.username || event.user || "",
      event.source_ip || "",
      event.destination_host || event.dest || "",
      event.event_type || "",
      event.result || ""
    ])
  );

  const breakdown = data.riskBreakdown || [];
  renderTable(
    "risk-breakdown-container",
    ["User", "Rule", "Severity", "Incident IDs", "Evidence"],
    breakdown.map(item => [
      item.username || "",
      item.rule_id || "",
      item.severity || "",
      (item.incidents || []).join(", "),
      (item.evidence_source || []).join(", ")
    ])
  );

  const graph = data.graph || {};
  const nodes = graph.nodes || [];
  const edges = graph.edges || [];
  const nodeMap = new Map(
    nodes.map(node => [node.id || node.name, node])
  );

  renderTable(
    "communication-graph-container",
    ["Source node", "Destination node", "Connections"],
    edges.map(edge => {
      const source = nodeMap.get(edge.source) || {};
      const target = nodeMap.get(edge.target) || {};
      return [
        source.label || source.name || edge.source || "",
        target.label || target.name || edge.target || "",
        edge.weight || edge.count || 1
      ];
    })
  );

  renderTable(
    "visualized-incidents-container",
    ["Incident", "Severity", "Score", "Entity", "Start time", "Rules"],
    (data.incidents || []).map(incident => [
      incident.id,
      incident.severity,
      incident.score,
      incident.entity,
      incident.start,
      (incident.rule_ids || []).join(", ")
    ])
  );
}

document.addEventListener("DOMContentLoaded", () => {
  $("analyze-form").addEventListener("submit", event => {
    if (!$("eval_file").files.length) {
      event.preventDefault();
      text("upload-error", "Please select an evaluation CSV.");
      return;
    }
    $("submit-btn").disabled = true;
    $("submit-btn").textContent = "Analyzing...";
  });

  $("q-entity").addEventListener("input", applyFilters);
  $("q-sev").addEventListener("change", applyFilters);
  $("q-score").addEventListener("input", applyFilters);

  $("reset-filters").addEventListener("click", () => {
    $("q-entity").value = "";
    $("q-sev").value = "ALL";
    $("q-score").value = "0";
    applyFilters();
  });

  $("close-panel").addEventListener("click", () => {
    $("detail-panel").style.display = "none";
  });

  if (HAS_RESULTS) {
    $("summary-bar").style.display = "grid";
    $("filter-bar").style.display = "flex";
    $("empty-state").style.display = "none";
    $("table-container").style.display = "block";

    text("st-total", METRICS.total);
    text("st-crithigh", METRICS.critical_high);
    text("st-maxscore", METRICS.max_score);
    text("st-users", METRICS.profiled_users);

    renderIncidents();
    applyFilters();
  }

  renderVisualizations(window.MISSION72_DATA || {});
});
</script>
<script src="/static/app.js"></script>
</body>
</html>
"""


# ---------------------------------------------------------------------
# Multipart CSV upload parsing
# ---------------------------------------------------------------------

def parse_multipart_form_data(
    headers: Any,
    rfile: Any,
) -> Tuple[Dict[str, Tuple[Optional[str], bytes]], Optional[str]]:
    """Parse multipart form data without the removed cgi module."""
    content_type = headers.get("Content-Type", "")

    if "multipart/form-data" not in content_type:
        return {}, "Invalid Content-Type: expected multipart/form-data"

    length_header = headers.get("Content-Length")
    if not length_header:
        return {}, "Missing Content-Length header"

    try:
        length = int(length_header)
    except ValueError:
        return {}, "Invalid Content-Length header"

    if length < 0:
        return {}, "Invalid negative Content-Length header"

    if length > MAX_UPLOAD_BYTES:
        return {}, "Upload exceeds the 50 MB limit"

    body = rfile.read(length)
    if len(body) != length:
        return {}, "Incomplete upload payload"

    try:
        mime_data = (
            b"Content-Type: "
            + content_type.encode("latin1", errors="replace")
            + b"\r\n\r\n"
            + body
        )
        message = email.message_from_bytes(
            mime_data,
            policy=email_default,
        )

        if not message.is_multipart():
            return {}, "Could not parse multipart upload"

        fields = {}

        for part in message.iter_parts():
            name = part.get_param("name", header="content-disposition")
            disposition = part.get("content-disposition", "")

            if not name and disposition:
                match = re.search(
                    r'name=["\']?([^"\';\r\n]+)',
                    disposition,
                )
                if match:
                    name = match.group(1).strip()

            if not name:
                continue

            filename = part.get_filename()
            if not filename and disposition:
                match = re.search(
                    r'filename=["\']?([^"\';\r\n]+)',
                    disposition,
                )
                if match:
                    filename = match.group(1).strip()

            payload = part.get_payload(decode=True) or b""
            fields[name] = (filename, payload)

        return fields, None

    except Exception as exc:
        return {}, f"Could not parse upload: {exc}"


# ---------------------------------------------------------------------
# HTTP request handler
# ---------------------------------------------------------------------

class InvestigatorRequestHandler(BaseHTTPRequestHandler):
    """HTTP routes for the local Mission 72 dashboard."""

    def log_message(self, format_string, *args):
        """Keep normal HTTP access logs enabled."""
        super().log_message(format_string, *args)

    def _get_request_path(self) -> str:
        raw_path = (
            self.headers.get("x-matched-path")
            or self.headers.get("x-forwarded-uri")
            or self.path
        )
        path = urllib.parse.urlparse(raw_path).path

        if path.startswith("/api/index"):
            path = path[len("/api/index"):] or "/"
        elif path.startswith("/api"):
            path = path[len("/api"):] or "/"

        return path

    def _send_bytes(
        self,
        data: bytes,
        content_type: str,
        status: int = 200,
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def _serve_static(self, filename: str, content_type: str) -> None:
        file_path = (STATIC_DIR / filename).resolve()

        # Only allow files from the configured static directory.
        if file_path.parent != STATIC_DIR.resolve():
            self.send_error(400, "Invalid static file path")
            return

        try:
            data = file_path.read_bytes()
        except OSError:
            self.send_error(404, f"Static file not found: {filename}")
            return

        self._send_bytes(data, content_type)

    def do_GET(self) -> None:
        path = self._get_request_path()

        if path in ("/", "/index.html"):
            self._render_dashboard()
        elif path == "/static/styles.css":
            self._serve_static("styles.css", "text/css; charset=utf-8")
        elif path == "/static/app.js":
            self._serve_static(
                "app.js",
                "application/javascript; charset=utf-8",
            )
        elif path == "/analyze-synthetic":
            self._analyze_synthetic()
        elif path == "/export/incidents.csv":
            self._export_csv("incidents")
        elif path == "/export/evidence.csv":
            self._export_csv("evidence")
        elif path == "/export/users.csv":
            self._export_csv("users")
        elif path == "/export/report.html":
            self._export_html()
        else:
            self.send_error(404, "Not found")

    def do_POST(self) -> None:
        if self._get_request_path() == "/analyze":
            self._handle_file_upload()
        else:
            self.send_error(404, "Not found")

    # -----------------------------------------------------------------
    # Analysis
    # -----------------------------------------------------------------

    def _analyze_events(self, training_events, evaluation_events, quality_report):
        """Run the existing detection and scoring pipeline."""
        context_registry = get_active_context_registry()

        baseline_repo = build_user_baselines(
            training_events,
            min_training_events=5,
        )

        engine = DetectionEngine(
            baseline_repo=baseline_repo,
            context_registry=context_registry,
        )

        alerts = engine.run_all(evaluation_events)

        incidents = group_alerts_into_incidents(
            alerts,
            context_registry=context_registry,
        )

        profiles = compute_user_risk_profiles(
            incidents,
            baseline_repo,
            evaluation_events,
            context_registry=context_registry,
        )

        GLOBAL_STATE.incidents = incidents
        GLOBAL_STATE.user_profiles = profiles
        GLOBAL_STATE.quality_report = quality_report
        GLOBAL_STATE.training_events_count = len(training_events)
        GLOBAL_STATE.evaluation_events_count = len(evaluation_events)

    def _load_synthetic_into_state(self) -> None:
        """Load and analyze the project's synthetic datasets."""
        train_path = PROJECT_ROOT / "data" / "synthetic" / "synthetic_training_auth.csv"
        eval_path = PROJECT_ROOT / "data" / "synthetic" / "synthetic_evaluation_auth.csv"

        if not train_path.exists() or not eval_path.exists():
            from mission72.synthetic import generate_synthetic_datasets

            generate_synthetic_datasets(
                str(PROJECT_ROOT / "data" / "synthetic")
            )

        if not train_path.exists() or not eval_path.exists():
            raise FileNotFoundError(
                "Synthetic datasets were not found or generated."
            )

        with train_path.open("r", encoding="utf-8-sig") as stream:
            training_events, _ = parse_csv_stream(
                stream,
                source_file=str(train_path),
            )

        with eval_path.open("r", encoding="utf-8-sig") as stream:
            evaluation_events, quality_report = parse_csv_stream(
                stream,
                source_file=str(eval_path),
            )

        self._analyze_events(
            training_events,
            evaluation_events,
            quality_report,
        )

    def _handle_file_upload(self) -> None:
        fields, error = parse_multipart_form_data(
            self.headers,
            self.rfile,
        )

        if error:
            self.send_error(400, error)
            return

        evaluation_item = fields.get("eval_file")

        if not evaluation_item or not evaluation_item[1].strip():
            self.send_error(
                400,
                "An evaluation CSV file is required.",
            )
            return

        try:
            training_events = []
            training_item = fields.get("train_file")

            if training_item and training_item[1].strip():
                training_filename = (
                    training_item[0] or "uploaded_training.csv"
                )
                training_text = training_item[1].decode(
                    "utf-8-sig",
                    errors="replace",
                )

                training_events, _ = parse_csv_stream(
                    io.StringIO(training_text),
                    source_file=training_filename,
                )

            evaluation_filename = (
                evaluation_item[0] or "uploaded_evaluation.csv"
            )
            evaluation_text = evaluation_item[1].decode(
                "utf-8-sig",
                errors="replace",
            )

            evaluation_events, quality_report = parse_csv_stream(
                io.StringIO(evaluation_text),
                source_file=evaluation_filename,
            )

            self._analyze_events(
                training_events,
                evaluation_events,
                quality_report,
            )

        except Exception as exc:
            self.send_error(
                400,
                f"Could not analyze the uploaded CSV: {exc}",
            )
            return

        self.send_response(303)
        self.send_header("Location", "/")
        self.end_headers()

    def _analyze_synthetic(self) -> None:
        try:
            self._load_synthetic_into_state()
        except Exception as exc:
            self.send_error(
                500,
                f"Could not load synthetic benchmark: {exc}",
            )
            return

        self.send_response(303)
        self.send_header("Location", "/")
        self.end_headers()

    # -----------------------------------------------------------------
    # Dashboard rendering
    # -----------------------------------------------------------------

    def _render_dashboard(self) -> None:
        if not GLOBAL_STATE.incidents and (
            os.environ.get("VERCEL")
            or os.environ.get("RENDER")
            or os.environ.get("PRELOAD_BENCHMARK")
        ):
            try:
                self._load_synthetic_into_state()
            except Exception as exc:
                print(f"Warning: synthetic preload failed: {exc}")

        incidents_data = build_dashboard_incidents()

        metrics = {
            "total": len(GLOBAL_STATE.incidents),
            "critical_high": sum(
                1
                for incident in GLOBAL_STATE.incidents
                if incident.severity in ("CRITICAL", "HIGH")
            ),
            "max_score": max(
                (
                    incident.risk_score
                    for incident in GLOBAL_STATE.incidents
                ),
                default=0,
            ),
            "profiled_users": len(GLOBAL_STATE.user_profiles),
        }

        visualization_data = build_visualization_payload()

        html = (
            SERVER_HTML
            .replace(
                "__INCIDENT_JSON__",
                safe_json(incidents_data),
            )
            .replace(
                "__METRICS_JSON__",
                safe_json(metrics),
            )
            .replace(
                "__VISUALIZATION_JSON__",
                safe_json(visualization_data),
            )
            .replace(
                "__HAS_RESULTS__",
                "true" if GLOBAL_STATE.incidents else "false",
            )
        )

        self._send_bytes(
            html.encode("utf-8"),
            "text/html; charset=utf-8",
        )

    # -----------------------------------------------------------------
    # Exports
    # -----------------------------------------------------------------

    def _export_csv(self, kind: str) -> None:
        if not GLOBAL_STATE.incidents and (
            os.environ.get("VERCEL")
            or os.environ.get("RENDER")
            or os.environ.get("PRELOAD_BENCHMARK")
        ):
            try:
                self._load_synthetic_into_state()
            except Exception as exc:
                self.send_error(500, str(exc))
                return

        if kind == "incidents":
            csv_text = generate_incidents_csv(GLOBAL_STATE.incidents)
            filename = "mission72_incidents.csv"
        elif kind == "evidence":
            csv_text = generate_evidence_csv(GLOBAL_STATE.incidents)
            filename = "mission72_evidence.csv"
        else:
            csv_text = generate_user_risk_csv(GLOBAL_STATE.user_profiles)
            filename = "mission72_user_risk_profiles.csv"

        data = csv_text.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header(
            "Content-Disposition",
            f'attachment; filename="{filename}"',
        )
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _export_html(self) -> None:
        if not GLOBAL_STATE.incidents and (
            os.environ.get("VERCEL")
            or os.environ.get("RENDER")
            or os.environ.get("PRELOAD_BENCHMARK")
        ):
            try:
                self._load_synthetic_into_state()
            except Exception as exc:
                self.send_error(500, str(exc))
                return

        report = generate_html_report(
            GLOBAL_STATE.incidents,
            GLOBAL_STATE.user_profiles,
            GLOBAL_STATE.quality_report,
        )

        data = report.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header(
            "Content-Disposition",
            'attachment; filename="mission72_investigation_report.html"',
        )
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


# ---------------------------------------------------------------------
# Server startup
# ---------------------------------------------------------------------

def start_server(
    port: Optional[int] = None,
    host: Optional[str] = None,
) -> None:
    """Start the Mission 72 dashboard server."""
    if host is None:
        host = os.environ.get("HOST", "127.0.0.1")

    if port is None:
        port = int(os.environ.get("PORT", "8072"))

    server = ThreadingHTTPServer(
        (host, port),
        InvestigatorRequestHandler,
    )

    print(f"Mission 72 dashboard running at http://{host}:{port}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down Mission 72 dashboard.")
    finally:
        server.server_close()


if __name__ == "__main__":
    start_server(8072)